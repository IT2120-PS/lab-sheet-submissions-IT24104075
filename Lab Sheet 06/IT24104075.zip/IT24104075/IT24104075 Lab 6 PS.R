setwd("C:\\Users\\user\\OneDrive\\Desktop\\IT24104075")
# Exercise 1
# X ~ Binomial(n=50, p=0.85)

n <- 50
p <- 0.85

# (i) Distribution of X
# X ~ Binomial(n=50, p=0.85)

# (ii) Probability that at least 47 students passed
1 - pbinom(46, n, p)


# Exercise 2
# X ~ Poisson(lambda = 12)

lambda <- 12

# (i) Random Variable
# X = number of customer calls received per hour

# (ii) Distribution of X
# X ~ Poisson(lambda = 12)

# (iii) Probability that exactly 15 calls are received
dpois(15, lambda)
